package com.example.client.response;

import com.example.client.entity.RentEntity;
import com.example.client.entity.SaleEntity;

public class SaleResponse extends BaseResponse {
    private SaleEntity sale;
    public void RentResponse(boolean success, String message, SaleEntity sale) {
        //super(success, message);
        this.sale = sale;
    }
    public void SaleResponse(RentEntity sale) {
        //super (true,"Sale");
    }
}
