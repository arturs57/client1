package com.example.client;

import com.example.client.controller.ApplicationController;
import com.example.client.controller.EditObjectController;
import com.example.client.controller.EditRentController;
import com.example.client.entity.ObjectEntity;
import com.example.client.entity.RentEntity;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;

public class Application extends javafx.application.Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Application.class.getResource("main.fxml"));
        VBox mainApp = (VBox) fxmlLoader.load();
        Scene scene = new Scene(fxmlLoader.load(), 720, 548);
        stage.setTitle("Картотека Агентства Недвижимости");
        stage.setScene(scene);

        ApplicationController controller = fxmlLoader.getController();
        stage.show();
    }

    public static boolean showObjectEditDialog(ObjectEntity objectObj, int id) {
//        try {
//            FXMLLoader loader = new FXMLLoader();
//            loader.setLocation(Application.class.getResource("editObject.fxml"));
//            VBox page = (VBox) loader.load();
//            Stage dialogStage = new Stage();
//            dialogStage.setTitle("Редактирование книги");
//            dialogStage.initModality(Modality.WINDOW_MODAL);
//            Scene scene = new Scene(page);
//            dialogStage.setScene(scene);
//            EditObjectController controller = loader.getController();
//            controller.setDialogStage(dialogStage);
//            controller.setLabels(objectObj, id);
//            dialogStage.showAndWait();
//            return controller.isOkClicked();
//        } catch (IOException e) {
//            e.printStackTrace();
            return false;
    }
//    public static boolean showRentEditDialog(RentEntity rentObj, int id) {
//        try {
//            FXMLLoader loader = new FXMLLoader();
//            loader.setLocation(Application.class.getResource("editRent.fxml"));
//            AnchorPane page = (AnchorPane) loader.load();
//            Stage dialogStage = new Stage();
//            dialogStage.setTitle("Редактирование автора");
//            dialogStage.initModality(Modality.WINDOW_MODAL);
//            Scene scene = new Scene(page);
//            dialogStage.setScene(scene);
//            EditRentController controller = loader.getController();
//            controller.setDialogStage(dialogStage);
//            controller.setLabels(rentObj, id);
//            dialogStage.showAndWait();
//            return controller.isOkClicked();
//        } catch (IOException e) {
//            e.printStackTrace();
//            return false;
//        }
//    }
    public static void main(String[] args) {
        launch();
    }
}