package com.example.client.service;

public class ObjectService {
}
