package com.example.client.controller;

import com.example.client.Application;
import com.example.client.entity.ObjectEntity;
import com.example.client.entity.RentEntity;
import com.example.client.entity.SaleEntity;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;

public class ApplicationController {

//    public static String api = "http://localhost:2825/api/v1/object/";

    public static ObservableList<ObjectEntity> objectData = FXCollections.observableArrayList();
    public static ObservableList<RentEntity> rentData = FXCollections.observableArrayList();
    public static ObservableList<SaleEntity> saleData = FXCollections.observableArrayList();

    //static HTTPUtils http = new HTTPUtils();
  //  static Gson gson = new Gson();


    @FXML
    private TableView<ObjectEntity> tableObjects;

//    @FXML
//    private TableColumn<ObjectEntity, String> objectId;

    @FXML
    private TableColumn<ObjectEntity, String> objectRoom;

    @FXML
    private TableColumn<ObjectEntity, String> objectPrice;

    @FXML
    private TableColumn<ObjectEntity, String> objectName;

    @FXML
    private TableColumn<ObjectEntity, String> objectStorey;

    @FXML
    private TableColumn<ObjectEntity, String> objectFootage;

    @FXML
    private TableView<RentEntity> tableRent;

//    @FXML
//    private TableColumn<RentEntity, String> rentId;

    @FXML
    private TableColumn<RentEntity, String> rentRoom;

    @FXML
    private TableColumn<RentEntity, String> rentPrice;

    @FXML
    private TableColumn<RentEntity, String> rentName;

    @FXML
    private TableColumn<RentEntity, String> rentStorey;

    @FXML
    private TableColumn<RentEntity, String> rentFootage;

    @FXML
    private TableView<SaleEntity> tableSale;

//    @FXML
//    private TableColumn<SaleEntity, String> saleId;

    @FXML
    private TableColumn<SaleEntity, String> saleRoom;

    @FXML
    private TableColumn<SaleEntity, String> salePrice;

    @FXML
    private TableColumn<SaleEntity, String> saleName;

    @FXML
    private TableColumn<SaleEntity, String> saleStorey;

    @FXML
    private TableColumn<SaleEntity, String> saleFootage;

    @FXML
    private void initialize() throws Exception {
       // getDataObjects();
        updateObjectTable();
        updateRentTable();
        updateSaleTable();
    }

    private void updateObjectTable() throws Exception {
        objectName.setCellValueFactory(new PropertyValueFactory<ObjectEntity, String>("Название"));
        objectRoom.setCellValueFactory(new PropertyValueFactory<ObjectEntity, String>("Комнат"));
        objectStorey.setCellValueFactory(new PropertyValueFactory<ObjectEntity, String>("Этаж"));
        objectFootage.setCellValueFactory(new PropertyValueFactory<ObjectEntity, String>("Метраж"));
        objectPrice.setCellValueFactory(new PropertyValueFactory<ObjectEntity, String>("Цена"));
        tableObjects.setItems(objectData);
    }

    private void updateRentTable() throws Exception {
        rentName.setCellValueFactory(new PropertyValueFactory<RentEntity, String>("Название"));
        rentRoom.setCellValueFactory(new PropertyValueFactory<RentEntity, String>("Комнат"));
        rentStorey.setCellValueFactory(new PropertyValueFactory<RentEntity, String>("Этаж"));
        rentFootage.setCellValueFactory(new PropertyValueFactory<RentEntity, String>("Метраж"));
        rentPrice.setCellValueFactory(new PropertyValueFactory<RentEntity, String>("Цена"));
        tableRent.setItems(rentData);
    }

    private void updateSaleTable() throws Exception {
        saleName.setCellValueFactory(new PropertyValueFactory<SaleEntity, String>("Название"));
        saleRoom.setCellValueFactory(new PropertyValueFactory<SaleEntity, String>("Комнат"));
        saleStorey.setCellValueFactory(new PropertyValueFactory<SaleEntity, String>("Этаж"));
        saleFootage.setCellValueFactory(new PropertyValueFactory<SaleEntity, String>("Метраж"));
        salePrice.setCellValueFactory(new PropertyValueFactory<SaleEntity, String>("Цена"));
        tableSale.setItems(saleData);
    }

    @FXML
    private void newBook() throws IOException {
        ObjectEntity tempObject = new ObjectEntity();
        objectData.add(tempObject);
        Application.showObjectEditDialog(tempObject, objectData.size() - 1);
    }

//    public static void getDataObjects() throws Exception {
//        String res = http.get(api, "all");
//        System.out.println(res);
//        JsonObject base = gson.fromJson(res, JsonObject.class);
//
//        JsonArray dataArr = base.getAsJsonArray("data");
//        for (int i = 0; i < dataArr.size(); i++) {
//            ObjectEntity newBook = gson.fromJson(dataArr.get(i).toString(), ObjectEntity.class);
//           objectData.add(newObject);
//        }
//    }

}
