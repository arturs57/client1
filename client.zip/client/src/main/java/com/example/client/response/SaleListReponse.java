package com.example.client.response;

import com.example.client.entity.RentEntity;
import com.example.client.entity.SaleEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class SaleListReponse {
    private Iterable<SaleEntity> data;
    public SaleListReponse(Iterable<SaleEntity> data) {
        //super(true, "Арендованные");
        this.data = data;
    }
}
