package com.example.client.response;

import com.example.client.entity.ObjectEntity;
import com.example.client.entity.RentEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class RentResponse extends BaseResponse {
    private RentEntity rent;
    public void RentResponse(boolean success, String message, RentEntity rent) {
        //super(success, message);
        this.rent = rent;
    }
    public void RentResponse(RentEntity rent) {
        //super (true,"Rent");
    }
}
