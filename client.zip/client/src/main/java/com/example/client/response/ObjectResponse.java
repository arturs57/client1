package com.example.client.response;

import com.example.client.entity.ObjectEntity;

public class ObjectResponse extends BaseResponse {
    private ObjectEntity object;

    public ObjectResponse(boolean success, String message, ObjectEntity object) {
        super(success, message);
        this.object = object;
    }
}
