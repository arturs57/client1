package com.example.client.entity;

import lombok.Data;

import java.util.List;

@Data
public class RentEntity {
    private Long id;
    private String name_object;
    private int price_object;
    private int storey_object;
    private int room_object;
    private int footage_object;

//    @Override
//    public String toString() {
//        return surname + ' ' + name.toUpperCase().charAt(0) + ". " + lastname.toUpperCase().charAt(0) + ". ";
//    }
}
