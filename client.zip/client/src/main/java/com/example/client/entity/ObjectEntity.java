package com.example.client.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class ObjectEntity {
    private Long id;
    private String name_object;
    private int price_object;
    private int storey_object;
    private int room_object;
    private int footage_object;
}
