package com.example.client.response;

import com.example.client.entity.RentEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class RentListResponse {
    private Iterable<RentEntity> data;
    public RentListResponse(Iterable<RentEntity> data) {
        //super(true, "Арендованные");
        this.data = data;
    }
}
