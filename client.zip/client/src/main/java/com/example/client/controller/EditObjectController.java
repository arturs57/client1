package com.example.client.controller;

public class EditObjectController {
}
