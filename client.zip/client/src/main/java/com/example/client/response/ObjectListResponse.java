package com.example.client.response;

import com.example.client.entity.ObjectEntity;

import java.util.List;

public class ObjectListResponse extends BaseResponse {
    public List<ObjectEntity> data;
    public ObjectListResponse(List<ObjectEntity> data) {
        super(true, "Доступные квартиры");
        this.data = data;
    }
}
